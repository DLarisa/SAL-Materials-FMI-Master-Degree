#include <stdio.h>
#include <stdlib.h>

typedef int val_type;
typedef unsigned int size_type;
